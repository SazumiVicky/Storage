let handler = async (m, { conn }) => {
   let teks = text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.text
	conn.sendFile(m.chat, 'https://api.lolhuman.xyz/api/playstore?apikey=31fe0c7b7761a4dcb6d8e227&query=${teks}', 'playstore.jpg', 'Nih kak\n2023 © Dann-MD', m)
}
handler.help = ['playstore']
handler.tags = ['internet']

handler.command = /^(playstore|appstore)$/i
handler.premium = false
handler.register = true
handler.limit = 1
module.exports = handler